package com.example.webservisproje.services;
import com.example.webservisproje.entity.PersonelDbEntity;

public interface PersonelService {
    public Boolean personelBul(String personelMail, String personelTckn);

}
