package com.example.webservisproje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebservisprojeApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebservisprojeApplication.class, args);
	}

}
