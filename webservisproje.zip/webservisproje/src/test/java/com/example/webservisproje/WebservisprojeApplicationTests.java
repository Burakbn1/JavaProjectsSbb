package com.example.webservisproje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebservisprojeApplicationTests {

	@Test
	void contextLoads() {
	}

}
